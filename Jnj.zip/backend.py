import csv
import sys
import os
import datetime
from openpyxl import *
from bs4 import BeautifulSoup as BS
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException

productLine = ['LCS', 'LVC', 'Phaco']
owners = 'Ashok TV, Manas Mondal, Anand Umadi, Andrew Jesiah, Kiran Kalliguddi,Sekar M, Vasistha Bollepally,Vinod Deshpande,Prajwal CR,Nikhil Pauskar,Prashanth Kumar B,Jayaganesh K,Suryaprakash M'

def checkCM(htmlSource):
    soup = BS(htmlSource, "lxml")
    bold = soup.find_all('b')
    for eachText in bold:
        if eachText.text.strip() == 'Complaint Manager Home Page':
            return True
    return False

def tableCopy(browser):
    data = []
    soup = BS(browser.page_source, "lxml")
    tables = soup.find_all('table', {'id': 'TBQueryFormResults'})
    for tr in tables[0].find_all('tr'):
        cols = [td.text.strip() for td in tr.find_all('td')]
        data.append(cols)
    return data

def writeToWorkBook(data, workBookName, sheetName):
    book = load_workbook(workBookName)
    sheet = book.get_sheet_by_name(sheetName)
    for row in data:
        sheet.append(row)
    sheet.delete_rows(1, 1)
    book.save(workBookName)

def QuerySelect(browser, query):
    browser.find_element_by_xpath("(//font[@face='Verdana'][contains(.,'Home')])[1]").click() #Home
    CM = checkCM(browser.page_source)
    if CM:
        browser.find_element_by_xpath('//*[@id="TDDisplayPart004"]/font/a/font').click()
        
    browser.find_element_by_xpath('//*[@id="TDDisplayPart014"]/font/a/font').click() #Queries
    select = Select(browser.find_element_by_xpath("(//select[@id='CTRLCategory'])[2]")) 
    select.select_by_value(query)
    browser.find_element_by_xpath('//*[@id="TBActionQueyCat1"]/tbody/tr[2]/td/input').click()
    return browser

def goToTable(browser, country, product, filepath):
    select = Select(browser.find_element_by_xpath('//*[@id="CTRLMyCountryParameter"]'))
    try:
        select.select_by_value(country)
    except:
        pass
    del select
    #SELECT PRODUCTLINE
    select = Select(browser.find_element_by_xpath('//*[@id="CTRLMyProductLineParameter"]'))
    select.select_by_value(product)
    browser.find_element_by_xpath('//*[@id="CTRLDPPARAMS1"]').click()
    
    getFromTable(browser, filepath)
           
def getFromTable(browser, filepath):
    data = []
    soup = BS(browser.page_source, "lxml")
    table = soup.find_all('table')
    for tr in table[4].find_all('tr'):
        cols = [td.text.strip() for td in tr.find_all('td')]
        if cols:
            del cols[0:7]
            del cols[1:3]
            del cols[4:8]
            data.append(cols)
    del data[0]

    book = load_workbook(filepath)
    sheet = book.get_sheet_by_name('Daily Report')
    maxrow= sheet.max_row
    for i in range(maxrow+1, maxrow+len(data)+1):
        sheet.cell(row = i, column = 1, value = data[i-(maxrow+1)][0])
        sheet.cell(row = i, column = 8, value = data[i-(maxrow+1)][1])
        sheet.cell(row = i, column = 7, value = data[i-(maxrow+1)][2])
        sheet.cell(row = i, column = 6, value = data[i-(maxrow+1)][3])
        sheet.cell(row = i, column = 4, value = 20)

    book.save(filepath)
    

def start(browser):
    countries = []
    browser.find_element_by_xpath("(//font[@face='Verdana'][contains(.,'Home')])[1]").click() #Home
    CM = checkCM(browser.page_source)
    if CM:
        browser.find_element_by_xpath('//*[@id="TDDisplayPart004"]/font/a/font').click()

    browser.find_element_by_xpath('//*[@id="TDDisplayPart002"]/font/a/font').click()
    select_box = browser.find_element_by_name("MyCountryParameter")
    options = [x for x in select_box.find_elements_by_tag_name("option")]
    for element in options:
        if element.get_attribute("value") != "Japan":
            countries.append(element.get_attribute("value"))

    del countries[0]
    return(browser, countries)

def dailyReport(browser):
    browser = QuerySelect(browser,'Complaint Folder')

    browser.find_element_by_xpath('//*[@id="TDCAPStatusStr"]/input').click() #Record Status	
    browser.find_element_by_xpath('//*[@id="CTRLcbg_StatusStr_Open"]').click() #Open
    browser.find_element_by_xpath('//*[@id="CTRLcbg_StatusStr_Ongoing"]').click() #Ongoing
    browser.find_element_by_xpath('//*[@id="CTRLcbg_StatusStr_Completed"]').click() #Completed
    browser.find_element_by_xpath('//*[@id="TDCAPStandardText003"]/input').click() #Current Step
    browser.find_element_by_xpath('//*[@id="TDCAPStandardText029"]/input').click() #Primary Complaint Owner
    pco = browser.find_element_by_xpath('//*[@id="CTRLStandardText029"]')
    pco.send_keys(owners)
    browser.find_element_by_xpath('//*[@id="TDCAPStandardText069"]/input').click() #Medical Event
    browser.find_element_by_xpath('//*[@id="TDCAPStandardDate010"]/input').click() #Received date
    browser.find_element_by_xpath('//*[@id="TDCAPStandardText011"]/input').click() #Product Line
    browser.find_element_by_xpath('//*[@id="TDCAPStandardText037"]/input').click() #Country
    browser.find_element_by_xpath('//*[@id="TDCAPDateClosedGoal"]/input').click() #Target Close Date
    browser.find_element_by_xpath('//*[@id="CTRLSUBMIT"]').click()
    return browser

def pREStatus(browser):
    browser = QuerySelect(browser,'pRE')

    browser.find_element_by_xpath('//*[@id="TDCAPUserAssigned"]/input').click() #Assigned to
    pco1 = browser.find_element_by_xpath('//*[@id="CTRLUserAssigned"]')
    pco1.send_keys(owners)
    browser.find_element_by_xpath('//*[@id="TDCAPStatusStr"]/input').click() #Record Status
    browser.find_element_by_xpath('//*[@id="CTRLcbg_StatusStr_Open"]').click() #Open
    #browser.find_element_by_xpath('//*[@id="CTRLcbg_StatusStr_Ongoing"]').click() #Ongoing
    #browser.find_element_by_xpath('//*[@id="CTRLcbg_StatusStr_Completed"]').click() #Completed
    browser.find_element_by_xpath('//*[@id="TDCAPStandardLongInteger001"]/input').click() #Complaint Folder
    browser.find_element_by_xpath('//*[@id="TDCAPDateClosedGoal"]/input').click() #Due Date
    browser.find_element_by_xpath('//*[@id="CTRLSUBMIT"]').click() #Submit
    return browser

def FSEStatus(browser):
    browser = QuerySelect(browser,'Field Service')

    browser.find_element_by_xpath('//*[@id="TDCAPUserAssigned"]/input').click() #Assigned to
    pco2 = browser.find_element_by_xpath("//input[@id='CTRLUserAssigned']")
    pco2.send_keys(owners)
    browser.find_element_by_xpath('//*[@id="TDCAPStatusStr"]/input').click() #Record Status
    browser.find_element_by_xpath('//*[@id="CTRLcbg_StatusStr_Open"]').click() #Open
    browser.find_element_by_xpath('//*[@id="CTRLcbg_StatusStr_Ongoing"]').click() #Ongoing
    browser.find_element_by_xpath('//*[@id="CTRLcbg_StatusStr_Completed"]').click() #Completed
    browser.find_element_by_xpath('//*[@id="TDCAPStandardLongInteger001"]/input').click() #Complaint Folder
    browser.find_element_by_xpath('//*[@id="TDCAPStandardText002"]/input').click() #Field service status
    browser.find_element_by_xpath('//*[@id="TDCAPStandardText011"]/input').click() #Product Line
    pl = browser.find_element_by_xpath('//*[@id="CTRLStandardText011"]')
    pl.send_keys('LCS, LVC, Phaco')
    browser.find_element_by_xpath('//*[@id="CTRLSUBMIT"]').click() #Submit
    return browser

def finalTouch(folder_path):
    book = load_workbook(folder_path)
    sheet = book.get_sheet_by_name('Daily Report')
    sheet['J1'] = 'Current Date'
    sheet['K1'] = 'Age as per Received date'
    sheet['L1'] = 'pRE Due Date'
    sheet['M1'] = 'pRE Due in Days'
    sheet['N1'] = 'FSE Status'

    maxrow= sheet.max_row
    current_date = datetime.datetime.now()

    for i in range(2, maxrow+1):
        sheet.cell(row = i, column = 10, value = current_date.strftime("%m/%d/%Y")) #Current Date
        sheet.cell(row = i, column = 11, value = '=DATEDIF(E:E,J:J,"d")') #Age as per Received Date
        #sheet.cell(row = i, column = 12, value = '=VLOOKUP(A%d,pRE Status!D:E,2,FALSE)' % i) #pRE Due Date
        sheet.cell(row = i, column = 13, value = '=DATEDIF(J:J,L:L,"d")') #pRE Due in days
        #sheet.cell(row = i, column = 14, value = '=VLOOKUP(A%d,FSE Status!D:E,2,FALSE)' % i) #FSE Status
    
    book.save(folder_path)

    







