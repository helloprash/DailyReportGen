import base64
from subprocess import Popen
import os, sys, inspect, time  
import threading
import queue as Queue
from tkinter import *
from tkinter import messagebox
from tkinter import filedialog
from tkinter.ttk import *
from tkinter import scrolledtext
from pathlib import Path
from Images import *
from openpyxl import *
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
import backend


class Window(object):
    def __init__(self,window,queue,clicked):
        self.window = window
        self.queue = queue
        self.window.geometry("611x379")
        self.window.configure(background='SystemWindow')
        self.window.title('Welcome')
        self.window.resizable(False, False)

        icondata= base64.b64decode(Jnjicon)
        tempFile= "icon.ico"
        iconfile= open(tempFile,"wb")
        iconfile.write(icondata)
        iconfile.close()
        self.window.wm_iconbitmap(tempFile)
        os.remove(tempFile)

        self.background_image=PhotoImage(data=background_img)
        self.background_label = Label(window, image=self.background_image)
        self.background_label.place(x=0, y=0, relwidth=1, relheight=1)

        style = Style()
        style.configure("BW.TLabel", font = ('Montserrat','10', 'bold'),foreground="#112D25", background="#DBDDDC")
        style.configure("BW.TButton", font = ('Montserrat','10','bold'), foreground="#112D25", background="#DBDDDC")
        style.configure("BW.TEntry", background="gray90")

        '''
        self.photo = PhotoImage(data=JNJvisioncare)
        self.w = Label(window, image=self.photo)
        self.w.pack()
        '''
        self.lblLink = Label(window, text="Link:", style="BW.TLabel")
        self.entLink = Entry(window, style="BW.TEntry")
        self.lblName = Label(window, text="Designed & Developed by Prashanth Kumar", font = ('Montserrat','8'),foreground="#112D25", background="#E3E4E6")
        self.lblName.place(x='389', y='362')
        self.lblLink.place(x='300', y='30')
        self.entLink.place(x='350', y='29')

        self.btn = Button(window, text="Submit", style="BW.TButton", command=clicked)
        #self.buttonImage=PhotoImage(data=Submit)
        #self.btn.config(image=self.buttonImage,width="45",height="10")
        self.btn.place(x='500', y='27')
 
        self.txt = scrolledtext.ScrolledText(window,width=34,height=17,font = ('Montserrat','10', 'bold'), relief = FLAT, background="#E3E4E6", foreground="#112D25")
        self.txt.vbar.config(troughcolor = 'red', bg = 'blue')
        self.txt.place(x='343', y='88')
        

    def processIncoming(self):
        """Handle all messages currently in the queue, if any."""
        while self.queue.qsize(  ):
            try:
                msg = self.queue.get(0)
                # Check contents of message and do whatever is needed. As a
                # simple test, print it (in real life, you would
                # suitably update the GUI's display in a richer fashion).
                if msg == 'clear':
                    self.txt.delete('1.0', END)
                else:
                    self.txt.insert(INSERT,msg)
                    self.txt.insert(INSERT,'\n')
                    self.txt.see("end")
                    print(msg)
            except Queue.Empty:
                # just on general principles, although we don't
                # expect this branch to be taken in this case
                pass


class ThreadedClient:
    """
    Launch the main part of the GUI and the worker thread. periodicCall and
    endApplication could reside in the GUI part, but putting them here
    means that you have all the thread controls in a single place.
    """
    def __init__(self, master):
        """
        Start the GUI and the asynchronous threads. We are in the main
        (original) thread of the application, which will later be used by
        the GUI as well. We spawn a new thread for the worker (I/O).
        """
        self.master = master

        self.running = 1

        # Create the queue
        self.queue = Queue.Queue(  )

        # Set up the GUI part
        self.gui = Window(master, self.queue, self.clicked)
        

    def periodicCall(self):
        """
        Check every 200 ms if there is something new in the queue.
        """
        self.gui.processIncoming()
        if not self.running:
            # This is the brutal stop of the system. You may want to do
            # some cleanup before actually shutting it down.
            self.running = 0
        self.master.after(200, self.periodicCall)

    
    def  clicked(self):
        inputLink = self.gui.entLink.get()
        current_folder = os.path.realpath(os.path.abspath(os.path.split(inspect.getfile(inspect.currentframe() ))[0]))
        batch_file = '\\\\'.join(os.path.join(current_folder,"kill.bat").split('\\'))
        print(batch_file)
        try:
            Popen(batch_file)
            time.sleep(2)
        except FileNotFoundError as fe:
            print(fe)
            messagebox.showinfo('Error!','Kill.bat not found')
            sys.exit()
            
        if not inputLink:
            messagebox.showinfo('Error!', 'Insert the CatsWeb link!')
        else:
            self.gui.btn.config(state="disabled")
            #global folder_path
            file_path =  filedialog.asksaveasfilename(initialdir = "/",title = "Save as",filetypes = (("excel files","*.xlsx"),("all files","*.*")))
            #filename = Path(file_path).name
            folder_path = '\\\\'.join(file_path.split('/'))

            # Set up the thread to do asynchronous I/O
            # More threads can also be created and used, if necessary
            self.running = 1
            self.thread1 = threading.Thread(target=self.workerThread1, args=(inputLink, folder_path+'.xlsx'))
            self.thread1.start()

            # Start the periodic call in the GUI to check if the queue contains anything
            self.periodicCall()
            #print(inputLink, folder_path)

    def workerThread1(self, url, folder_path):
        while self.running:
            self.queue.put('Initializing... Please wait')
            productLine = ['LCS', 'LVC', 'Phaco']

            current_folder = os.path.realpath(os.path.abspath(os.path.split(inspect.getfile(inspect.currentframe() ))[0]))
            pjs_file = '\\\\'.join(os.path.join(current_folder,"phantomjs.exe").split('\\'))

            browser = webdriver.PhantomJS(executable_path = pjs_file)
            try:
                browser.get(url)
            except:
                self.queue.put('clear')
                self.queue.put('Invalid link :(')
                browser.quit()
                break

            book = Workbook()
            sheet1 = book.active
            sheet1.title = 'Daily Report'
            book.create_sheet('pRE Status')
            book.create_sheet('FSE Status')
            book.save(folder_path)
                
#Daily Report
            browser = backend.dailyReport(browser)
            DailyReportData = backend.tableCopy(browser)
            backend.writeToWorkBook(DailyReportData, folder_path, 'Daily Report')
            self.queue.put('clear')
            self.queue.put('Old files Done...')

#pRE Status
            browser = backend.pREStatus(browser)
            pREData = backend.tableCopy(browser)
            backend.writeToWorkBook(pREData, folder_path, 'pRE Status')
            self.queue.put('pRE Status Done...')

#FSE Status
            browser = backend.FSEStatus(browser)
            FSEData = backend.tableCopy(browser)
            backend.writeToWorkBook(FSEData, folder_path, 'FSE Status')
            self.queue.put('FSE Status Done...')
        
#New Files
            (browser, countries) = backend.start(browser)
            self.queue.put('clear')
            self.queue.put('Downloading new files...\n\n')
        
            for country in countries:
                self.queue.put(country)
                print(country)
                for product in productLine:
                    self.queue.put('\t\t'+product)
                    #print('\t\t',product)
                    backend.goToTable(browser, country, product, folder_path)

                self.queue.put('-----------------------')    
                print("----------------------------------------------------------")
            self.queue.put('New files downloaded') 

#Fill excel
            backend.finalTouch(folder_path)
            self.queue.put('clear')
            self.queue.put('Report generated at location:\n'+folder_path)
            print('\nHave a good day...')
            self.running = 0
            browser.quit()


#code for the GUI (front end)
window = Tk()
client = ThreadedClient(window)
window.mainloop()

